"use strict";exports.id=9549,exports.ids=[9549],exports.modules={69549:(a,b,c)=>{c.d(b,{p:()=>g});var d=c(88299),e=c(32132),f=c(78378);class g{static async getConfig(){try{let a=await d.prisma.systemProfile.findFirst();if(a?.commConfig)try{let b=JSON.parse(a.commConfig);if(b&&(b.emailProvider||b.whatsapp))return b}catch{}let b=!!process.env.SMTP_HOST&&!!process.env.SMTP_USER;return process.env.RESEND_API_KEY&&process.env.RESEND_API_KEY,{emailProvider:b?"SMTP":"RESEND",smtp:{host:process.env.SMTP_HOST||"smtp.gmail.com",port:Number(process.env.SMTP_PORT)||465,secure:"true"===process.env.SMTP_SECURE||465===Number(process.env.SMTP_PORT),user:process.env.SMTP_USER||"",pass:process.env.SMTP_PASS||"",fromName:a?.name||"Proxima SMS Academy",fromEmail:process.env.SMTP_FROM||process.env.SMTP_USER||"bursary@proxima.edu"},resend:{apiKey:process.env.RESEND_API_KEY||"",fromEmail:process.env.RESEND_FROM_EMAIL||"onboarding@resend.dev"},whatsapp:{enabled:"true"===process.env.WHATSAPP_ENABLED,gatewayType:process.env.WHATSAPP_GATEWAY||"EVOLUTION_API",apiUrl:process.env.WHATSAPP_API_URL||"http://localhost:8080",apiKey:process.env.WHATSAPP_API_KEY||"",instanceName:process.env.WHATSAPP_INSTANCE||"school-alerts"}}}catch{return{emailProvider:"RESEND",resend:{apiKey:process.env.RESEND_API_KEY||"",fromEmail:process.env.RESEND_FROM_EMAIL||"onboarding@resend.dev"}}}}static async saveConfig(a){try{let b=await d.prisma.systemProfile.findFirst();if(!b)return{success:!1,error:"System profile not found."};return await d.prisma.systemProfile.update({where:{id:b.id},data:{commConfig:JSON.stringify(a)}}),{success:!0}}catch(a){return{success:!1,error:a.message||"Failed to persist communication settings."}}}static async sendEmail(a){let b=await this.getConfig(),d=Array.isArray(a.to)?a.to:[a.to],g=a.bcc||[],h=d.length+g.length;if(0===h)return{success:!0,provider:"NONE",sentCount:0,failedCount:0};if("SMTP"===b.emailProvider&&b.smtp?.host&&b.smtp.user)try{let d=e.createTransport({host:b.smtp.host,port:b.smtp.port,secure:b.smtp.secure,auth:{user:b.smtp.user,pass:b.smtp.pass},tls:{rejectUnauthorized:!1}}),f=`"${b.smtp.fromName||"School Management"}" <${b.smtp.fromEmail||b.smtp.user}>`,g=a.html;if(!g&&a.react){let{render:b}=await c.e(4309).then(c.bind(c,44309));g=await b(a.react)}let i=await d.sendMail({from:f,to:a.to,bcc:a.bcc,subject:a.subject,text:a.text,html:g});return{success:!0,provider:"SMTP",messageId:i.messageId,sentCount:h,failedCount:0}}catch(a){return console.error("[CommEngine] SMTP Send Failure:",a),{success:!1,provider:"SMTP",sentCount:0,failedCount:h,errors:[a.message||"SMTP delivery failed."]}}if(b.resend?.apiKey&&"re_dummy_key"!==b.resend.apiKey)try{let e=new f.u(b.resend.apiKey),h=b.resend.fromEmail||"onboarding@resend.dev",i=b.smtp?.fromName||"Proxima SMS Academy",j=h.includes("onboarding@resend.dev"),k=a.html;if(!k&&a.react){let{render:b}=await c.e(4309).then(c.bind(c,44309));k=await b(a.react)}let l=Array.from(new Set([...d,...g])),m=0,n=0,o=[];for(let b of l)try{let c=await e.emails.send({from:`${i} <${h}>`,to:[b],subject:a.subject,html:k||a.text||""});c.error?(n++,o.push(`${b}: ${c.error.message}`)):m++}catch(a){n++,o.push(`${b}: ${a.message}`)}let p=m>0,q=j&&n>0?"Resend is in Sandbox Mode (onboarding@resend.dev). Non-testing domains are rejected by Resend. Configure custom domain or switch to SMTP.":void 0;return{success:p||0===m&&j,provider:"RESEND",sentCount:m,failedCount:n,errors:o.slice(0,5),warning:q}}catch(a){return console.error("[CommEngine] Resend Send Failure:",a),{success:!1,provider:"RESEND",sentCount:0,failedCount:h,errors:[a.message||"Resend delivery failed."]}}return{success:!1,provider:"NONE",sentCount:0,failedCount:h,errors:["No email gateway configured. Please setup SMTP or Resend in System Configuration."]}}static formatPhoneNumber(a,b="234"){let c=a.replace(/\D/g,"");return c?c.startsWith("0")&&11===c.length?b+c.substring(1):c.startsWith("234")&&13===c.length||c.length>=10?c:b+c:""}static async sendWhatsApp(a,b){let c=(await this.getConfig()).whatsapp;if(!c||!c.enabled||!c.apiUrl)return{success:!1,error:"WhatsApp gateway is currently disabled or unconfigured in System Settings."};let d=this.formatPhoneNumber(a);if(!d)return{success:!1,error:"Invalid recipient phone number."};try{let a=c.apiUrl.replace(/\/$/,"");if("EVOLUTION_API"===c.gatewayType){let e=`${a}/message/sendText/${c.instanceName||"school-alerts"}`,f=await fetch(e,{method:"POST",signal:AbortSignal.timeout(8e3),headers:{"Content-Type":"application/json",...c.apiKey?{apikey:c.apiKey}:{}},body:JSON.stringify({number:d,options:{delay:1200,presence:"composing"},textMessage:{text:b}})});if(!f.ok){let a=await f.text();throw Error(`Evolution API error HTTP ${f.status}: ${a}`)}let g=await f.json();return{success:!0,messageId:g?.key?.id||"EVO-OK"}}if("WAHA"===c.gatewayType){let e=`${a}/api/sendText`,f=await fetch(e,{method:"POST",signal:AbortSignal.timeout(8e3),headers:{"Content-Type":"application/json",...c.apiKey?{"X-Api-Key":c.apiKey}:{}},body:JSON.stringify({chatId:`${d}@c.us`,text:b,session:c.instanceName||"default"})});if(!f.ok){let a=await f.text();throw Error(`WAHA API error HTTP ${f.status}: ${a}`)}let g=await f.json();return{success:!0,messageId:g?.id||"WAHA-OK"}}let e=await fetch(a,{method:"POST",signal:AbortSignal.timeout(8e3),headers:{"Content-Type":"application/json",...c.apiKey?{Authorization:`Bearer ${c.apiKey}`}:{}},body:JSON.stringify({to:d,message:b,timestamp:new Date().toISOString()})});if(!e.ok)throw Error(`Webhook error HTTP ${e.status}`);return{success:!0}}catch(a){return console.error("[CommEngine] WhatsApp Dispatch Error:",a),{success:!1,error:a.message||"Failed to dispatch WhatsApp message."}}}static async testSmtp(a,b){try{let c=e.createTransport({host:a.host,port:a.port,secure:a.secure,auth:{user:a.user,pass:a.pass},tls:{rejectUnauthorized:!1}});return await c.verify(),await c.sendMail({from:`"${a.fromName||"Proxima SMS"}" <${a.fromEmail||a.user}>`,to:b,subject:"Proxima SMS - SMTP Gateway Verified",html:`
          <div style="font-family: sans-serif; padding: 24px; color: #0f172a; max-width: 500px; border: 1px solid #e2e8f0; border-radius: 12px;">
            <h2 style="color: #10b981; margin-bottom: 8px;">SMTP Connection Successful</h2>
            <p style="font-size: 14px; line-height: 1.5;">This verification message confirms that your school's SMTP gateway is authenticated and actively transmitting.</p>
            <table style="border-collapse: collapse; font-size: 13px; margin: 16px 0; width: 100%;">
              <tr style="border-bottom: 1px solid #f1f5f9;"><td style="padding: 6px 0; font-weight: bold; color: #64748b;">Host:</td><td style="font-family: monospace;">${a.host}:${a.port}</td></tr>
              <tr style="border-bottom: 1px solid #f1f5f9;"><td style="padding: 6px 0; font-weight: bold; color: #64748b;">Account:</td><td style="font-family: monospace;">${a.user}</td></tr>
              <tr><td style="padding: 6px 0; font-weight: bold; color: #64748b;">Encryption:</td><td>${a.secure?"SSL/TLS (Port 465)":"STARTTLS (Port 587)"}</td></tr>
            </table>
            <p style="font-size: 11px; color: #94a3b8; margin-top: 16px;">Dispatched from Proxima SMS Communications Core.</p>
          </div>
        `}),{success:!0,message:`Handshake verified! Test email delivered to ${b}.`}}catch(a){return{success:!1,message:a.message||"SMTP verification failed."}}}static async testWhatsApp(a,b){if(!a.apiUrl)return{success:!1,message:"API URL is required."};let c=this.formatPhoneNumber(b);if(!c)return{success:!1,message:"Valid phone number is required."};let d=`Proxima SMS WhatsApp Gateway Test: Verification ping sent successfully at ${new Date().toLocaleTimeString()}.`;try{let b=a.apiUrl.replace(/\/$/,"");if("EVOLUTION_API"===a.gatewayType){let e=`${b}/message/sendText/${a.instanceName||"school-alerts"}`,f=await fetch(e,{method:"POST",signal:AbortSignal.timeout(8e3),headers:{"Content-Type":"application/json",...a.apiKey?{apikey:a.apiKey}:{}},body:JSON.stringify({number:c,options:{delay:1e3,presence:"composing"},textMessage:{text:d}})});if(!f.ok){let a=await f.text();return{success:!1,message:`Evolution API HTTP ${f.status}: ${a}`}}return{success:!0,message:`Test message dispatched to +${c} via Evolution API.`}}if("WAHA"===a.gatewayType){let e=`${b}/api/sendText`,f=await fetch(e,{method:"POST",signal:AbortSignal.timeout(8e3),headers:{"Content-Type":"application/json",...a.apiKey?{"X-Api-Key":a.apiKey}:{}},body:JSON.stringify({chatId:`${c}@c.us`,text:d,session:a.instanceName||"default"})});if(!f.ok){let a=await f.text();return{success:!1,message:`WAHA API HTTP ${f.status}: ${a}`}}return{success:!0,message:`Test message dispatched to +${c} via WAHA.`}}let e=await fetch(b,{method:"POST",signal:AbortSignal.timeout(8e3),headers:{"Content-Type":"application/json",...a.apiKey?{Authorization:`Bearer ${a.apiKey}`}:{}},body:JSON.stringify({to:c,message:d,timestamp:new Date().toISOString()})});if(!e.ok)return{success:!1,message:`Webhook responded with HTTP ${e.status}.`};return{success:!0,message:"Test payload delivered to webhook URL."}}catch(a){return{success:!1,message:a.message||"WhatsApp connection test failed."}}}static async sendReceiptNotification(a){let b=await this.getConfig(),c=b.smtp?.fromName||"Proxima SMS Academy",d=`₦${a.amountPaid.toLocaleString("en-NG",{minimumFractionDigits:2})}`,e=`₦${a.balanceRemaining.toLocaleString("en-NG",{minimumFractionDigits:2})}`,f=a.date.toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}),g=!1,h=!1;if(a.guardianEmail&&a.guardianEmail.includes("@")){let b=`
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 580px; margin: 0 auto; background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
          <div style="background-color: #0f172a; padding: 28px 24px; text-align: center; color: #ffffff;">
            <h1 style="margin: 0; font-size: 20px; font-weight: 700; letter-spacing: -0.02em;">${c}</h1>
            <p style="margin: 6px 0 0 0; font-size: 13px; color: #94a3b8;">Official Fee Payment Receipt</p>
          </div>
          <div style="padding: 28px 24px;">
            <p style="font-size: 15px; color: #334155; margin-top: 0;">Dear <strong>${a.guardianName}</strong>,</p>
            <p style="font-size: 14px; color: #475569; line-height: 1.6;">
              We acknowledge receipt of your school fee payment for <strong>${a.studentName}</strong> (${a.className}). Details of this transaction are documented below:
            </p>
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin: 20px 0;">
              <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Receipt Number:</td>
                  <td style="padding: 8px 0; text-align: right; font-family: monospace; font-weight: 700; color: #0f172a;">${a.receiptNumber}</td>
                </tr>
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Student:</td>
                  <td style="padding: 8px 0; text-align: right; color: #0f172a;">${a.studentName} (${a.studentId})</td>
                </tr>
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Date:</td>
                  <td style="padding: 8px 0; text-align: right; color: #0f172a;">${f}</td>
                </tr>
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Payment Method:</td>
                  <td style="padding: 8px 0; text-align: right; color: #0f172a; text-transform: uppercase;">${a.paymentMethod}</td>
                </tr>
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 8px 0; color: #15803d; font-weight: 700; font-size: 14px;">Amount Paid:</td>
                  <td style="padding: 8px 0; text-align: right; font-weight: 800; font-size: 16px; color: #15803d;">${d}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Outstanding Balance:</td>
                  <td style="padding: 8px 0; text-align: right; font-weight: 700; color: ${a.balanceRemaining>0?"#b91c1c":"#15803d"};">${e}</td>
                </tr>
              </table>
            </div>
            <p style="font-size: 13px; color: #64748b; line-height: 1.5; margin-bottom: 0;">
              Thank you for your prompt commitment towards academic excellence. This digital receipt serves as official proof of payment.
            </p>
          </div>
          <div style="background-color: #f1f5f9; padding: 16px 24px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0;">
            Bursary & Accounts Division &bull; ${c}
          </div>
        </div>
      `;try{g=(await this.sendEmail({to:a.guardianEmail,subject:`Payment Receipt: ${a.receiptNumber} - ${a.studentName}`,html:b,text:`Payment Receipt for ${a.studentName}. Amount Paid: ${d}. Outstanding Balance: ${e}. Receipt: ${a.receiptNumber}.`})).success}catch(a){console.error("[CommEngine] Receipt email error:",a)}}if(a.guardianPhone&&b.whatsapp?.enabled){let b=`*${c.toUpperCase()} - FEE RECEIPT*

Dear ${a.guardianName},
We confirm receipt of *${d}* for *${a.studentName}* (${a.className}).

*Receipt No:* ${a.receiptNumber}
*Date:* ${f}
*Method:* ${a.paymentMethod.toUpperCase()}
*Balance Remaining:* ${e}

Thank you for your partnership.`;try{h=(await this.sendWhatsApp(a.guardianPhone,b)).success}catch(a){console.error("[CommEngine] Receipt WhatsApp error:",a)}}return{emailSent:g,whatsappSent:h}}static async sendFeeReminder(a){let b=await this.getConfig(),c=b.smtp?.fromName||"Proxima SMS Academy",d=a.currencySymbol||"₦",e=`${d}${a.amountDue.toLocaleString("en-NG",{minimumFractionDigits:2})}`,f=!1,g=!1;if(a.guardianEmail&&a.guardianEmail.includes("@")){let b=`
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 580px; margin: 0 auto; background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
          <div style="background-color: #0f172a; padding: 28px 24px; text-align: center; color: #ffffff;">
            <h1 style="margin: 0; font-size: 20px; font-weight: 700; letter-spacing: -0.02em;">${c}</h1>
            <p style="margin: 6px 0 0 0; font-size: 13px; color: #94a3b8;">Tuition & Fee Reminder</p>
          </div>
          <div style="padding: 28px 24px;">
            <p style="font-size: 15px; color: #334155; margin-top: 0;">Dear <strong>${a.guardianName}</strong>,</p>
            <p style="font-size: 14px; color: #475569; line-height: 1.6;">
              This is a gentle reminder regarding the outstanding school fee obligation for <strong>${a.studentName}</strong> (${a.className}).
            </p>
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin: 20px 0;">
              <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Invoice Number:</td>
                  <td style="padding: 8px 0; text-align: right; font-family: monospace; font-weight: 700; color: #0f172a;">${a.invoiceNumber}</td>
                </tr>
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Student:</td>
                  <td style="padding: 8px 0; text-align: right; color: #0f172a;">${a.studentName} (${a.studentId})</td>
                </tr>
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Due Date:</td>
                  <td style="padding: 8px 0; text-align: right; color: #dc2626; font-weight: 700;">${a.dueDate}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Amount Outstanding:</td>
                  <td style="padding: 8px 0; text-align: right; font-weight: 800; font-size: 16px; color: #dc2626;">${e}</td>
                </tr>
              </table>
            </div>
            ${a.paymentLink?`
            <div style="text-align: center; margin: 24px 0;">
              <a href="${a.paymentLink}" style="display: inline-block; background-color: #2563eb; color: #ffffff; padding: 12px 28px; font-size: 14px; font-weight: 600; text-decoration: none; border-radius: 8px;">
                Pay Invoice Online
              </a>
            </div>
            `:""}
            <p style="font-size: 13px; color: #64748b; line-height: 1.5; margin-bottom: 0;">
              Please arrange for settlement on or before the due date to ensure uninterrupted academic sessions. If you have already made payment, kindly notify the bursary with your proof of payment.
            </p>
          </div>
          <div style="background-color: #f1f5f9; padding: 16px 24px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0;">
            Bursary & Accounts Division &bull; ${c}
          </div>
        </div>
      `;try{f=(await this.sendEmail({to:a.guardianEmail,subject:`Fee Reminder: ${a.studentName} - Outstanding Balance (${a.invoiceNumber})`,html:b,text:`Fee Reminder for ${a.studentName}. Outstanding Balance: ${e}. Due Date: ${a.dueDate}. Invoice: ${a.invoiceNumber}.`})).success}catch(a){console.error("[CommEngine] Reminder email error:",a)}}if(a.guardianPhone&&b.whatsapp?.enabled){let b=`*${c.toUpperCase()} - FEE REMINDER*

Dear ${a.guardianName},
This is a reminder regarding the outstanding fee of *${e}* for *${a.studentName}* (${a.className}).

*Invoice:* ${a.invoiceNumber}
*Due Date:* ${a.dueDate}
`+(a.paymentLink?`*Pay Online:* ${a.paymentLink}

`:"\n")+"Kindly ensure payment is concluded promptly. Thank you.";try{g=(await this.sendWhatsApp(a.guardianPhone,b)).success}catch(a){console.error("[CommEngine] Reminder WhatsApp error:",a)}}return{success:f||g,emailSent:f,whatsappSent:g,warning:f||g?void 0:"Gateway not configured or delivery skipped"}}static async sendStaffWelcomeNotification(a){let b=await this.getConfig(),c=b.smtp?.fromName||"Proxima SMS Academy",d=a.loginUrl||process.env.NEXTAUTH_URL||"http://localhost:3000/login",e=`
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 580px; margin: 0 auto; background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
        <div style="background-color: #0f172a; padding: 28px 24px; text-align: center; color: #ffffff;">
          <h1 style="margin: 0; font-size: 20px; font-weight: 700; letter-spacing: -0.02em;">${c}</h1>
          <p style="margin: 6px 0 0 0; font-size: 13px; color: #94a3b8;">Staff Onboarding & Access Credentials</p>
        </div>
        <div style="padding: 28px 24px;">
          <p style="font-size: 15px; color: #334155; margin-top: 0;">Dear <strong>${a.staffName}</strong>,</p>
          <p style="font-size: 14px; color: #475569; line-height: 1.6;">
            Welcome to the academic and operational faculty at <strong>${c}</strong>. Your staff profile has been provisioned on the school management portal.
          </p>
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin: 20px 0;">
            <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Staff ID:</td>
                <td style="padding: 8px 0; text-align: right; font-family: monospace; font-weight: 700; color: #0f172a;">${a.staffId}</td>
              </tr>
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Assigned Role:</td>
                <td style="padding: 8px 0; text-align: right; font-weight: 600; color: #0f172a;">${a.role}</td>
              </tr>
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Portal Username / Email:</td>
                <td style="padding: 8px 0; text-align: right; font-weight: 600; color: #0f172a;">${a.staffEmail}</td>
              </tr>
              ${a.temporaryPassword?`
              <tr>
                <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Temporary Password:</td>
                <td style="padding: 8px 0; text-align: right; font-family: monospace; font-weight: 700; color: #2563eb;">${a.temporaryPassword}</td>
              </tr>
              `:""}
            </table>
          </div>
          <div style="text-align: center; margin: 24px 0;">
            <a href="${d}" style="display: inline-block; background-color: #0f172a; color: #ffffff; padding: 12px 28px; font-size: 14px; font-weight: 600; text-decoration: none; border-radius: 8px;">
              Sign In to Staff Portal
            </a>
          </div>
          <p style="font-size: 12px; color: #64748b; line-height: 1.5; margin-bottom: 0;">
            Security Notice: For security precautions, you will be prompted to update your password upon your initial sign-in. Do not share your credentials with unauthorized personnel.
          </p>
        </div>
        <div style="background-color: #f1f5f9; padding: 16px 24px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0;">
          Human Resources & Registry &bull; ${c}
        </div>
      </div>
    `;try{return{emailSent:(await this.sendEmail({to:a.staffEmail,subject:`Welcome to ${c} - Staff Portal Access Credentials`,html:e,text:`Welcome to ${c}. Your Staff ID is ${a.staffId}. Access the portal at ${d}.`})).success}}catch(a){return console.error("[CommEngine] Staff welcome email error:",a),{emailSent:!1}}}static async sendAttendanceAbsenceAlert(a){let b=await this.getConfig(),c=b.smtp?.fromName||"Proxima SMS Academy",d=a.date.toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}),e=!1,f=!1;if(a.guardianEmail&&a.guardianEmail.includes("@")){let b=`
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 580px; margin: 0 auto; background-color: #ffffff; border: 1px solid #fee2e2; border-radius: 12px; overflow: hidden;">
          <div style="background-color: #991b1b; padding: 24px; text-align: center; color: #ffffff;">
            <h1 style="margin: 0; font-size: 18px; font-weight: 700;">${c}</h1>
            <p style="margin: 6px 0 0 0; font-size: 13px; color: #fecaca;">Attendance Alert: Student Absent</p>
          </div>
          <div style="padding: 24px;">
            <p style="font-size: 15px; color: #334155; margin-top: 0;">Dear <strong>${a.guardianName}</strong>,</p>
            <p style="font-size: 14px; color: #475569; line-height: 1.6;">
              Please be informed that <strong>${a.studentName}</strong> was marked <strong>ABSENT</strong> from roll call for <strong>${a.className}</strong> on <strong>${d}</strong>.
            </p>
            <div style="background-color: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 14px; margin: 16px 0; font-size: 13px; color: #991b1b;">
              If this absence was unexpected, kindly contact the school administration or class supervisor immediately.
            </div>
            <p style="font-size: 12px; color: #64748b; margin-bottom: 0;">Automated Academic Safety & Roll Call Service.</p>
          </div>
        </div>
      `;try{e=(await this.sendEmail({to:a.guardianEmail,subject:`Attendance Alert: ${a.studentName} Marked Absent (${d})`,html:b,text:`Attendance Notice: ${a.studentName} was marked absent for ${a.className} on ${d}. Contact the school if this was unexpected.`})).success}catch(a){console.error("[CommEngine] Absence email error:",a)}}if(a.guardianPhone&&b.whatsapp?.enabled){let b=`*${c.toUpperCase()} - ATTENDANCE NOTICE*

Dear ${a.guardianName},
Please be notified that *${a.studentName}* was marked *ABSENT* for *${a.className}* on *${d}*.

If this absence was unplanned, please contact the school administration immediately.`;try{f=(await this.sendWhatsApp(a.guardianPhone,b)).success}catch(a){console.error("[CommEngine] Absence WhatsApp error:",a)}}return{emailSent:e,whatsappSent:f}}static async sendGradeAlert(a){let b=await this.getConfig(),c=b.smtp?.fromName||"Proxima SMS Academy",d=Math.round(a.score/(a.maxScore||100)*100),e=!1,f=!1;if(a.recipientEmail&&a.recipientEmail.includes("@")){let b=`
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 580px; margin: 0 auto; background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
          <div style="background-color: #0f172a; padding: 24px; text-align: center; color: #ffffff;">
            <h1 style="margin: 0; font-size: 18px; font-weight: 700;">${c}</h1>
            <p style="margin: 6px 0 0 0; font-size: 13px; color: #94a3b8;">Academic Assessment Result Published</p>
          </div>
          <div style="padding: 24px;">
            <p style="font-size: 15px; color: #334155; margin-top: 0;">Dear <strong>${a.recipientName}</strong>,</p>
            <p style="font-size: 14px; color: #475569; line-height: 1.6;">
              A new assessment has been evaluated for <strong>${a.studentName}</strong> in <strong>${a.courseOrSubject}</strong>:
            </p>
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin: 16px 0;">
              <table style="width: 100%; font-size: 13px;">
                <tr><td style="color: #64748b; font-weight: 600;">Assessment:</td><td style="text-align: right; font-weight: 700;">${a.assessmentTitle}</td></tr>
                <tr><td style="color: #64748b; font-weight: 600;">Score:</td><td style="text-align: right; font-weight: 800; font-size: 16px; color: #16a34a;">${a.score} / ${a.maxScore} (${d}%)</td></tr>
                ${a.feedback?`<tr><td style="color: #64748b; font-weight: 600; vertical-align: top; padding-top: 6px;">Feedback:</td><td style="text-align: right; color: #334155; padding-top: 6px; font-style: italic;">"${a.feedback}"</td></tr>`:""}
              </table>
            </div>
            <p style="font-size: 12px; color: #64748b; margin-bottom: 0;">Log into the student / parent portal to review the comprehensive gradebook.</p>
          </div>
        </div>
      `;try{e=(await this.sendEmail({to:a.recipientEmail,subject:`Grade Published: ${a.assessmentTitle} - ${a.studentName} (${a.score}/${a.maxScore})`,html:b,text:`Grade Released: ${a.studentName} received ${a.score}/${a.maxScore} in ${a.courseOrSubject} for "${a.assessmentTitle}".`})).success}catch(a){console.error("[CommEngine] Grade email error:",a)}}if(a.recipientPhone&&b.whatsapp?.enabled){let b=`*${c.toUpperCase()} - GRADE RELEASED*

Dear ${a.recipientName},
The assessment results for *${a.studentName}* have been posted:

*Course/Subject:* ${a.courseOrSubject}
*Assessment:* ${a.assessmentTitle}
*Score:* ${a.score} / ${a.maxScore} (${d}%)
`+(a.feedback?`*Lecturer Feedback:* "${a.feedback}"

`:"\n")+"Review complete academic progress on the parent portal.";try{f=(await this.sendWhatsApp(a.recipientPhone,b)).success}catch(a){console.error("[CommEngine] Grade WhatsApp error:",a)}}return{emailSent:e,whatsappSent:f}}}}};